Meghna OnePage HTML5 Business Template
========
<img src="https://cloud.githubusercontent.com/assets/10640964/6306960/0ac45dea-b962-11e4-8bd6-f7d5283701e1.jpg" />

========
Meghna is a Responsive minimalist, simple, elegant and clean style, a strong focus on contents and readability. It presents a modern business solution. Meghna is suitable for websites such as business, company, portfolio . It is superbly responsive adapting to any kinds of smart phones and mobile devices. Code is easy to modify and understand so you can personalize it in the easiest way.
