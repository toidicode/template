## Title : Grocery Store Template

## AUTHOR: Rutik Bhoyar

- Github : https://github.com/Rutikab12
- Twitter: https://twitter.com/RutikBhoyar


## Home Screen
<img width="1440" src="../Kirana Store Template/img 1.PNG">


## Features
<img width="1440" src="../Kirana Store Template/img 2.PNG">


## Products
<img width="1440" src="../Kirana Store Template/img 3.PNG">


## Categories
<img width="1440" src="../Kirana Store Template/img 4.PNG">


## Review
<img width="1440" src="../Kirana Store Template/img 5.PNG">


## Blogs
<img width="1440" src="../Kirana Store Template/img 6.PNG">
