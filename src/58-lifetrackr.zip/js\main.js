$(document).ready(function() {
 
  
      // Owl carousel
    $("#owl-example").owlCarousel(
    {
        items :1,
        autoPlay : true,
        pagination : false,
    });
 
});
